import json
import pandas as pd
import requests
import boto3
import io
from urllib.parse import urlparse
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize S3 client
s3 = boto3.client('s3')



def process_jobs(input_data):
    # Convert bytes to DataFrame
    df = pd.read_csv(io.BytesIO(input_data))

    # Remove duplicate jobids
    df = df.drop_duplicates(subset='job_posting_id')

    # Ensure is_active column exists, fill missing with 0 (inactive)
    if 'is_active' not in df.columns:
        df['is_active'] = 0
    else:
        df['is_active'] = df['is_active'].fillna(0)

    # Convert DataFrame to CSV string
    csv_buffer = io.StringIO()
    df.to_csv(csv_buffer, index=False)
    return csv_buffer.getvalue()

def lambda_handler(event, context):
    try:
        # Get bucket and file details from the S3 event
        source_bucket = 'jla-jobids-pool'
        source_key = 'indeed_job_ids.csv'
        
        # Read the source file from S3
        response = s3.get_object(Bucket=source_bucket, Key=source_key)
        file_content = response['Body'].read()
        
        # Process the jobs data
        processed_content = process_jobs(file_content)
        
        # Upload processed file to destination bucket
        destination_bucket = 'jla-jobids-pool'
        destination_key = 'indeed_job_ids.csv'
        
        s3.put_object(
            Bucket=destination_bucket,
            Key=destination_key,
            Body=processed_content
        )
        
        logger.info(f"Successfully processed and uploaded to s3://{destination_bucket}/{destination_key}")
        
        return {
            'statusCode': 200,
            'body': json.dumps('Job processing completed successfully')
        }
        
    except Exception as e:
        logger.error(f"Error processing jobs: {str(e)}")
        raise e
