import json
import boto3
import os
import time

def lambda_handler(event, context):
    """
    Simplified Lambda function to create NAT Gateway
    
    Environment variables required:
    - VPC_ID: Your VPC ID (e.g., vpc-004d13a6aa725e304)
    - PUBLIC_SUBNET_ID: Your public subnet ID (where NAT Gateway will be created)
    - PRIVATE_ROUTE_TABLE_IDS: Comma-separated list of private route table IDs
    """
    
    # Get environment variables
    vpc_id = os.environ.get('VPC_ID')
    public_subnet_id = os.environ.get('PUBLIC_SUBNET_ID')
    private_route_tables = os.environ.get('PRIVATE_ROUTE_TABLE_IDS', '').split(',')
    
    if not all([vpc_id, public_subnet_id, private_route_tables]):
        return {
            'statusCode': 400,
            'body': json.dumps('Missing required environment variables')
        }
    
    ec2 = boto3.client('ec2')
    
    try:
        # Step 1: Check if NAT Gateway already exists
        nat_response = ec2.describe_nat_gateways(
            Filters=[
                {"Name": "vpc-id", "Values": [vpc_id]},
                {"Name": "state", "Values": ["available", "pending"]}
            ]
        )
        
        if nat_response['NatGateways']:
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': 'NAT Gateway already exists',
                    'nat_gateway_id': nat_response['NatGateways'][0]['NatGatewayId']
                })
            }
        
        # Step 2: Allocate Elastic IP
        eip_response = ec2.allocate_address(
            Domain='vpc',
            TagSpecifications=[{
                'ResourceType': 'elastic-ip',
                'Tags': [
                    {'Key': 'Name', 'Value': 'Databricks-NAT-EIP'},
                    {'Key': 'ManagedBy', 'Value': 'Lambda'}
                ]
            }]
        )
        allocation_id = eip_response['AllocationId']
        print(f"Created Elastic IP: {allocation_id}")
        
        # Step 3: Create NAT Gateway
        nat_response = ec2.create_nat_gateway(
            AllocationId=allocation_id,
            SubnetId=public_subnet_id,
            TagSpecifications=[{
                'ResourceType': 'natgateway',
                'Tags': [
                    {'Key': 'Name', 'Value': 'Databricks-NAT'},
                    {'Key': 'ManagedBy', 'Value': 'Lambda'}
                ]
            }]
        )
        nat_gateway_id = nat_response['NatGateway']['NatGatewayId']
        print(f"Created NAT Gateway: {nat_gateway_id}")
        
        # Step 4: Wait for NAT Gateway to be available
        waiter = ec2.get_waiter('nat_gateway_available')
        waiter.wait(
            NatGatewayIds=[nat_gateway_id],
            WaiterConfig={'Delay': 15, 'MaxAttempts': 40}
        )
        print("NAT Gateway is now available")
        
        # Step 5: Update route tables
        for rt_id in private_route_tables:
            if not rt_id.strip():
                continue
                
            try:
                # Check if route exists
                rt_response = ec2.describe_route_tables(RouteTableIds=[rt_id])
                routes = rt_response['RouteTables'][0].get('Routes', [])
                
                has_default_route = any(
                    r.get('DestinationCidrBlock') == '0.0.0.0/0' 
                    for r in routes
                )
                
                if has_default_route:
                    # Replace existing route
                    ec2.replace_route(
                        RouteTableId=rt_id,
                        DestinationCidrBlock='0.0.0.0/0',
                        NatGatewayId=nat_gateway_id
                    )
                    print(f"Replaced route in {rt_id}")
                else:
                    # Create new route
                    ec2.create_route(
                        RouteTableId=rt_id,
                        DestinationCidrBlock='0.0.0.0/0',
                        NatGatewayId=nat_gateway_id
                    )
                    print(f"Created route in {rt_id}")
                    
            except Exception as e:
                print(f"Error updating route table {rt_id}: {str(e)}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'NAT Gateway created successfully',
                'nat_gateway_id': nat_gateway_id,
                'elastic_ip_id': allocation_id
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'message': 'Failed to create NAT Gateway'
            })
        }
