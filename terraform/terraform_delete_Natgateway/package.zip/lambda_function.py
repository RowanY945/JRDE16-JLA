import json
import boto3
import os
import time

def lambda_handler(event, context):
    """
    Simplified Lambda function to delete NAT Gatewayss
    
    Environment variables required:
    - VPC_ID: Your VPC ID (e.g., vpc-004d13a6aa725e304)
    - PRIVATE_ROUTE_TABLE_IDS: Comma-separated list of private route table IDs
    """
    
    # Get environment variables
    vpc_id = os.environ.get('VPC_ID')
    private_route_tables = os.environ.get('PRIVATE_ROUTE_TABLE_IDS', '').split(',')
    
    if not all([vpc_id, private_route_tables]):
        return {
            'statusCode': 400,
            'body': json.dumps('Missing required environment variables')
        }
    
    ec2 = boto3.client('ec2')
    
    try:
        # Step 1: Find NAT Gateway in VPC
        nat_response = ec2.describe_nat_gateways(
            Filters=[
                {"Name": "vpc-id", "Values": [vpc_id]},
                {"Name": "state", "Values": ["available"]}
            ]
        )
        
        if not nat_response['NatGateways']:
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': 'No NAT Gateway found to delete'
                })
            }
        
        nat_gateway = nat_response['NatGateways'][0]
        nat_gateway_id = nat_gateway['NatGatewayId']
        allocation_id = nat_gateway['NatGatewayAddresses'][0]['AllocationId']
        
        print(f"Found NAT Gateway: {nat_gateway_id}")
        print(f"Associated Elastic IP: {allocation_id}")
        
        # Step 2: Delete routes pointing to NAT Gateway
        for rt_id in private_route_tables:
            if not rt_id.strip():
                continue
                
            try:
                ec2.delete_route(
                    RouteTableId=rt_id,
                    DestinationCidrBlock='0.0.0.0/0'
                )
                print(f"Deleted route from {rt_id}")
            except ec2.exceptions.InvalidRouteNotFound:
                print(f"No route to delete in {rt_id}")
            except Exception as e:
                print(f"Error deleting route from {rt_id}: {str(e)}")
        
        # Step 3: Delete NAT Gateway
        ec2.delete_nat_gateway(NatGatewayId=nat_gateway_id)
        print(f"Initiated deletion of NAT Gateway {nat_gateway_id}")
        
        # Step 4: Wait for NAT Gateway to be deleted
        waiter = ec2.get_waiter('nat_gateway_deleted')
        waiter.wait(
            NatGatewayIds=[nat_gateway_id],
            WaiterConfig={'Delay': 15, 'MaxAttempts': 40}
        )
        print("NAT Gateway deleted successfully")
        
        # Step 5: Release Elastic IP
        time.sleep(5)  # Small delay to ensure NAT Gateway is fully deleted
        
        try:
            ec2.release_address(AllocationId=allocation_id)
            print(f"Released Elastic IP {allocation_id}")
        except ec2.exceptions.InvalidAllocationIDNotFound:
            print("Elastic IP already released")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'NAT Gateway deleted successfully',
                'nat_gateway_id': nat_gateway_id,
                'elastic_ip_id': allocation_id
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'message': 'Failed to delete NAT Gateway'
            })
        }